import React from 'react';
import axios from 'axios';
import jsSha from 'jssha';
// import {Link} from 'react-router-dom';
// import ReactDOM from "react-dom";

import LoginForm from "./LoginForm";
export class LoginPage extends React.Component {
        constructor(params) {
          super(params);
          this.state = { clients: [] };
        };
        componentDidMount() {
          const user = 'lazymeercat116';
          const password = 'hottest';
          const hmac = new jsSha('SHA-256', 'TEXT');
          hmac.setHMACKey(password, 'TEXT');
          hmac.update(user);
          hmac.update(Date.now().toString(36).substring(0, 4));
          const token = `${hmac.getHMAC('HEX')}%${user}`;
          const api = axios.create({
            baseURL: 'http://45.77.58.134:8080',
            headers: { 'Authorization': 'Bearer ' + token }
          });
          (async () => {
            const res = await api.get('/clients');
            const accounts = await api.get(`/accounts/${res.data[0]._id}`)
            this.setState({clients: res.data});
            console.log(accounts);
          })();
        };
        render() {
          return <ul>
            {this.state.clients.map(x =>
              <li key={x._id}>
                {`${x.first} ${x.last} - ${x.id}`}
              </li>
            )}
          </ul>;
        }
      }
export default LoginPage;
