import React from 'react';
import {Link} from 'react-router-dom';
import ReactDOM from "react-dom";

const Buy = () => (
      <div>
        <h1>BUY PREPAID OR UTILITY SERVICES</h1>

      <Link to="/Prepaid">PREPAID</Link>
      <br/>
      </div>
    );

export default Buy;
