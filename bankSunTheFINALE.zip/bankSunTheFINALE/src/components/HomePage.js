import React from 'react';
import {Link} from 'react-router-dom';
import ReactDOM from "react-dom";

const HomePage = () => (
<div>

<div class="clearfix"></div>

<div class="jumbotron">
<h1 class="display-4">Open an account with us today!</h1>
<p class="lead">THE BANK OF THE SUN, PRIDE THEMSELVES IN MAKING SURE OUR CLIENTS NEEDS ARE ALWAYS MET.</p>

<p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
<p class="lead">
<a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</p>

</div>
</div>


);

export default HomePage;
