import React from 'react';
import {Link} from 'react-router-dom';
import ReactDOM from "react-dom";
const Payments = () => (
      <div>
        <h1>PAYMENTS</h1>

      <Link to="/Beneficiary">BENEFICIARY</Link>
      <br/>


      </div>
    );

export default Payments;
