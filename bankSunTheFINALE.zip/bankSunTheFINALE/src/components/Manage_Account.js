import React from 'react';
// import {Link} from 'react-router-dom';
// import ReactDOM from "react-dom";
// import './man_acc.css';
import { Table } from 'reactstrap';
const Manage_Account = () => (
      <div>
        <h1>MY ACCOUNT</h1>
        <meta charSet="utf-8" />
         <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
         <meta name="viewport" content="width=device-width, initial-scale=1" />
         <title>The Bank of the Sun</title>
         <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:700, 600,500,400,300" rel="stylesheet" type="text/css" />
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
         <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />
         <link rel="stylesheet" href="main.css" />
         <style dangerouslySetInnerHTML={{__html: "\n\t\t\t.ad {\n\t\t\t\tposition: absolute;\n\t\t\t\twidth: 300px;\n\t\t\t\theight: 250px;\n\t\t\t\tborder: 1px solid #ddd;\n\t\t\t\tleft: 50%;\n\t\t\t\ttransform: translateX(-50%);\n\t\t\t\ttop: 250px;\n\t\t\t\tz-index: 10;\n\t\t\t}\n\t\t\t.ad .close {\n\t\t\t\tposition: absolute;\n\t\t\t\tfont-family: 'ionicons';\n\t\t\t\twidth: 20px;\n\t\t\t\theight: 20px;\n\t\t\t\tcolor: #fff;\n\t\t\t\tbackground-color: #999;\n\t\t\t\tfont-size: 20px;\n\t\t\t\tleft: -20px;\n\t\t\t\ttop: -1px;\n\t\t\t\tdisplay: table-cell;\n\t\t\t\tvertical-align: middle;\n\t\t\t\tcursor: pointer;\n\t\t\t\ttext-align: center;\n\t\t\t}\n\t\t" }} />

{/* <style dangerouslySetInnerHTML={{__html: "\nbody {\n  background: #d7d9d9;\n  width: 100%;\n  margin: 60px 0;\n  font-size: 14px;\n  font-family: Arial, sans-serif;\n  -webkit-font-smoothing: antialiased;\n}\n\np {\n  text-align: center;\n  color: #8f9496;\n}\n\narticle {\n  background: #00000;\n  border: 1px solid #bbb;\n  border-radius: 4px;\n  float: left;\n  width: 140px;\n  margin: 0 auto 40px auto;\n  -webkit-box-shadow: 0px 0px 16px rgba(50, 50, 50, 0.24);\n}\n\n.card-header {\n  padding: 4px;\n  background: rgba(50, 50, 50, 50);\n  border-top-left-radius: 4px;\n  border-top-right-radius: 4px;\n  border-bottom: 1px solid #ccc;\n}\n\n.card-header button {\n  font-size: 13px;\n  cursor: pointer;\n  width: 100%;\n  background: #3498db;\n  border: none;\n  color: #fff;\n  border-radius: 4px;\n  padding: 8px;\n  -webkit-font-smoothing: antialiased;\n}\n\n.card-header button:hover {\n  background: #51a7e0;\n}\n\n.card-header img {\n  width: 132px;\n  border-radius: 2px;\n}\n\n.card-links {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n\n.card-links hr {\n  border-bottom: 0;\n  border-top: 1px solid #ddd;\n  margin: 0;\n}\n\n.card-links a {\n  text-decoration: none;\n  color: rgba(50, 50, 50, 50);\n}\n\n.card-links a li {\n  margin: 0;\n  padding: 14px 6px;\n  border-left: 4px solid #fff;\n  transition: background-color 0.2s ease,\n              border-left 0.2s ease,\n              color 0.2s ease;\n}\n\n.card-links a li:hover {\n  border-left: 4px solid #3498db;\n  background: rgba(50, 50, 50, 50);\n  color: #44474a;\n}\n\n.card-links a li.active {\n  border-left: 4px solid #e74c3c !important;\n  background: #f6f6f6;\n  color: #44474a;\n}\n\n.card-links a li i {\n  position: absolute;\n  margin-left: 4px;\n}\n\n.link-favorites {\n  border-bottom-left-radius: 4px;\n}\n\n.label {\n  position: relative;\n  left: 26px;\n  top: -1px;\n  font-size: 12px;\n}\n\n.label-notification {\n  float: right;\n  font-size: 10px;\n  color: #8f9496;\n  background: #eceded ;\n  padding: 4px;\n  border-radius: 4px;\n  margin: -2px 4px 0 0;\n  transition: background-color 0.2s ease,\n              color 0.2s ease;\n}\n\n.card-links a li:hover .label-notification,\n.label-active {\n  color: #44474a;\n  background: #d7d9d9;\n}\n\n#imageUpload\n{\n    display: none;\n}\n\n#profileImage\n{\n    cursor: pointer;\n}\n\n#profile-container {\n    width: 150px;\n    height: 150px;\n    overflow: hidden;\n    -webkit-border-radius: 50%;\n    -moz-border-radius: 50%;\n    -ms-border-radius: 50%;\n    -o-border-radius: 50%;\n    border-radius: 50%;\n}\n\n#profile-container img {\n    width: 150px;\n    height: 150px;\n}\n\n.btn{\n padding: 18px 28px;\n    font-size:18px;\n    font-weight: 500;\n    border-radius:5px;\n    text-decoration: none !important;\n    display: inline-block;\n    border: 0;\n    color: #222222;\n    text-transform: uppercase;\n    position: relative;\n    z-index: 2;\n    -webkit-transform: skew(-8deg);\n -moz-transform: skew(-8deg);\n -o-transform: skew(-8deg);\n}\n.font_30{font-size:30px !important;}\n\n.btn-default {\n    background-image: linear-gradient(to right top ,#6871f4,#6871f4,#6871f48f,#265db9 ,#265db9b0 )!important;\n    color: #fff !important;\n}\n.btn-default:before {\n    content: \"\";\n    position: absolute;\n    z-index: -1;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    display: block;\n    right: 0;\n    transform: scaleY(0);\n    transform-origin: 50%;\n    transition-property: transform;\n    transition-duration: 0.3s;\n    transition-timing-function: ease-out;\n}\n.btn-default:hover:before, .btn-default:focus:before {\n    transform: scaleY(1);\n    color: #fff!important;\n    border-radius: 5px;\n}\n.btn-default:hover .skew_14{\n  color:#fff;\n}\n.btn-primary {\n   background: #504cf5 !important;\n    color: #fff !important;\n  }\n\n.btn-primary:before {\n    content: \"\";\n    position: absolute;\n    z-index: -1;\n    background:#f256c8 !important;\n    top: 0;\n    bottom: 0;\n    left: 0;\n    display: block;\n    right: 0;\n    transform: scaleY(0);\n    transform-origin: 50%;\n    transition-property: transform;\n    transition-duration: 0.3s;\n    transition-timing-function: ease-out;\n}\n.btn-primary:hover:before, .btn-primary:focus:before {\n    transform: scaleY(1);\n    color: #fff !important;\n    border-radius: 5px;\n}\n.btn_text_cap{\n  text-transform: capitalize !important;\n  font-size: 20px;\npadding: 12px 28px;\n}\n.btn_bg_f{\n  background:#fff !important;\n  color:#000 !important;\n}\n.btn_bg_f:hover{\n  color:#fff !important;\n}\n\n.blog-img:before,.blog-img:after{\n  position:absolute;\n  top:0;\n  width:0;\n  height:100%;\n  content:\"\";\n  transition:all .5s;\n  -webkit-transition:all .5s;\n  -moz-transition:all .5s;\n  opacity:.5;\n}\n.blog-img:before{\n  left:0;\n}\n.blog-wrap:hover .blog-img:before{\n  width:50%;\n}\n.blog-img:after{\n  right:0;\n}\n.blog-wrap:hover .blog-img:after{\n  width:50%;\n}\n.blog-meta{\n  margin-bottom:10px;\n}\n.blog-meta ul li{\n  display:inline-block;\n  margin-right:10px;\n}\n.blog-meta ul li a{\n  color:#555 !important;\n}\n.blog-meta ul li a:hover{\n  color:#296dc1;\n}\n.blog-meta ul li a i{\n  margin-right:3px;\n}\n.blog-content{\n  position:relative;\n  padding:20px 20px 30px;\n  border-bottom:2px solid #c3c3c3;\n}\n.blog-content:before,.blog-content:after{\n  position:absolute;\n  left:0;\n  bottom:-2px;\n  width:10%;\n  height:2px;\n  background: #296dc1;\n  content:\"\";\n  transition:all .5s;\n  -webkit-transition:all .5s;\n  -moz-transition:all .5s;\n  opacity:.7;\n}\n.blog-wrap:hover .blog-content:before,.blog-wrap:hover .blog-content:after{\n  width:50%;\n}\n.blog-content:after{\n  left:auto;\n  right:0;\n}\n.blog-content h3{\n  margin-bottom:15px;\n}\n.blog-content h3 a{\n  font-size:20px;\n  text-transform:capitalize;\n  color:#555!important;\n}\n.blog-content p{\n  margin-bottom:20px;\n  line-height:24px;\n}\n.blog-content a.btn-style{\n  border:1px solid #296dc1;\n}\n\n.blog-img img {\n    width: 100%;\n}\n" }} /> */}

       <div className="header">
         <div className="logo">
           <i className="fa fa-tachometer" />
           <span>MANAGE MY ACCOUNT</span>
         </div>
         <a href="#" className="nav-trigger"><span /></a>
       </div>
       <div className="side-nav">
         <div className="logo">
           <i className="fa fa-tachometer" />
           <span>Profile</span>
         </div>
         <nav>
           <ul>
             <li className="active">
               <a href="#">
                 <span><i className="fa fa-user" /></span>
                 <span>Profile Details</span>
               </a>
             </li>
             <li>
               <a href="/Personal_Acc">
                 <span><i className="fa fa-money" /></span>
                 <span>Personal Banking</span>
               </a>
             </li>
             <li>
               <a href="/Business_Acc">
                 <span><i className="fa fa-bold" /></span>
                 <span>Business Banking</span>
               </a>
             </li>
             <li>
               <a href="/History_Transactions">
                 <span><i className="fa fa-credit-card" /></span>
                 <span>History &amp; Transactions</span>
               </a>
             </li>
             <li>
               <a href="#">
                 <span><i className="fa fa-credit-card" /></span>
                 <span>Account Summary</span>
               </a>
             </li>
           </ul>
         </nav>
         <div className="main-content">
              <div className="title">
                Welcome Back..
              </div>

              <div className="main">
                <Table striped>
               <thead>
                 <tr>
                   <th>Client_ID</th>
                   <th>Client_DOB</th>
                   <th>Client Email</th>
                   <th>Client_Firstname</th>
                   <th>Client ID</th>
                   <th>Client_Lastname</th>
                   <th>Client_Title</th>
                   <th>Client_Username</th>
                 </tr>
               </thead>
               <tbody>
                 <tr>

                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>

                 </tr>
                 <tr>

                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>

                 </tr>
                 <tr>

                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>
                   <td>####</td>

                 </tr>
               </tbody>
             </Table>
              </div>
            </div>
       </div>
       <p />
     </div>
   );


export default Manage_Account;
