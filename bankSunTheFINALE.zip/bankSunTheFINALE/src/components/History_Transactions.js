import React from 'react';
import {Link} from 'react-router-dom';
import ReactDOM from "react-dom";
import { Table } from 'reactstrap';

const History_Transactions = () => (
      <div>
        <h1>TRANSACTION HISTORY</h1>
        <Table striped>
       <thead>
         <tr>
           <th>Transaction_ID</th>
           <th>Transaction Amount</th>
           <th>Transaction Balance</th>
           <th>Transaction Destination</th>
           <th>Transaction Reference</th>
           <th>Transaction Source</th>
           <th>Transaction Time</th>
           <th>Transaction Type</th>
         </tr>
       </thead>
       <tbody>
         <tr>

           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
         </tr>
         <tr>

           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>

         </tr>
         <tr>

           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
           <td>####</td>
         </tr>
       </tbody>
     </Table>
      </div>
    );

export default History_Transactions;
