import React, { Component } from 'react';
import ReactDOM from "react-dom";
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import WelcomePage from "./components/WelcomePage";
import LoginPage from "./components/LoginPage";
import LoginForm from "./components/LoginForm";
import RegisterForm from "./components/RegisterForm";
import HomePage from "./components/HomePage";
import MainNav from "./components/MainNav";
import About from "./components/About";
import Payments from "./components/Payments";
import Beneficiary from "./components/Beneficiary";
import Buy from "./components/Buy";
import Prepaid from "./components/Prepaid";
import Manage_Account from "./components/Manage_Account";
import Transfers from "./components/Transfers";
import Sign_Out from "./components/Sign_Out";
import Personal_Acc from "./components/Personal_Acc";
import Business_Acc from "./components/Business_Acc";
import History_Transactions from "./components/History_Transactions";
import { Link } from 'react-router-dom';
// import axios from 'axios';
import bootstrap from "./components/bootstrap.css";

const App = () => (
      <div className= "ui container">

        <Link to='/HomePage'>Home</Link><br/>
        <Link to='/About'>About</Link><br/>
        <Link to ='/Payments'>Payments</Link><br/>
        <Link to='/Buy'>Buy</Link><br/>
        <Link to='/Transfers'>Transfers</Link><br/>
        <Link to='/Manage_Account'>Manage Account</Link><br/>
        <Link to='/Sign_Out'>Sign Out</Link><br/>

      <Route path="/WelcomePage" exact component={WelcomePage}/>
      <Route path="/LoginPage" exact component={LoginPage}/>
      <Route path="/LoginForm" exact component={LoginForm}/>
      <Route path="/RegisterForm" exact component={RegisterForm}/>
      <Route path="/HomePage" exact component={HomePage}/>
      <Route path="/MainNav" exact component={MainNav}/>
      <Route path="/About" exact component={About}/>
      <Route path="/Payments" exact component={Payments}/>
      <Route path="/Beneficiary" exact component={Beneficiary}/>
      <Route path="/Buy" exact component={Buy}/>
      <Route path="/Prepaid" exact component={Prepaid}/>
      <Route path="/Manage_Account" exact component={Manage_Account}/>
      <Route path="/Transfers" exact component={Transfers}/>
      <Route path="/Sign_Out" exact component={Sign_Out}/>
      <Route path="/Personal_Acc" exact component={Personal_Acc}/>
      <Route path="/Business_Acc" exact component={Business_Acc}/>
      <Route path="/History_Transactions" exact component={History_Transactions}/>

</div>
    );
export default App;
